<?php 

namespace app\components\listeners;

class RegisterListener
{
    public function handle ($data,$text){
/*   		var_dump($text);
    	var_dump($data);*/
    }
}