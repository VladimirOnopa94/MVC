<?php 

return [
	'title' => 'Головна',
	'title_test' => 'Тут добавленно :sum грн, а еще :text слово',

	'test1' => [
		'inner'=> 'innerText',
		'inner2' => [
			'inner3' => 'Тут добавленно :sum грн, а еще :text слово'
		],
	]
];