<?php 
return [
	'login_title' => 'Вхід',
	'wrong_pass' => 'Неверный логин или пароль',
];




