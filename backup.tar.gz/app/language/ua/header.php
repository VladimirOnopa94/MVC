<?php 
return [
	'main_title' => 'Головна',
	'category_title' => 'Категорії',
	'login_title' => 'Вхід',
	'logout_title' => 'Вихід',
	'signin_title' => 'Реєстрація',
	'welcome_title' => 'Ласкаво просимо',
	'phonebook_title' => 'Телефонна книга',
	'contact_title' => 'Мої контакти',
];
