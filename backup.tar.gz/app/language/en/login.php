<?php 
return [
	'login_title' => 'Login',
	'wrong_pass' => 'Wrong login or password',
];




