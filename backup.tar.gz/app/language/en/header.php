<?php 
return [
	'main_title' => 'Main',
	'category_title' => 'Categoryes',
	'login_title' => 'Login',
	'logout_title' => 'Logout',
	'signin_title' => 'Signin',
	'welcome_title' => 'Welcome',
	'phonebook_title' => 'Public Phonebook',
	'contact_title' => 'My Contact',
];
