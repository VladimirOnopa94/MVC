<?php 

return [
	'title' => 'Main',
];