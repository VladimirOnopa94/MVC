<?php 
namespace app\models;


/**
 * Класс исходной модели
 */
class Model extends \framework\core\Model
{


}