<!DOCTYPE html>
<html>
 <head>
   <style>
	p{
		font-weight: 25px;
		border:1px solid red;
	}
	</style>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

 </head>
 <body>
 <h1 style="font-weight: bold;color:red"><?php echo $var1; ?> </h1>

	<p>Пример сообщения</p>


 </body> 
</html>