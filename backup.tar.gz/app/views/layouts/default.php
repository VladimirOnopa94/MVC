<!doctype html>
<html lang="<?php echo getLang() ?>">
  <head>
  	<title><?php echo $this->getTitle(); ?></title>
    <base href="<?php echo siteUrl(); ?>">
    <meta charset="utf-8">
    <meta name="csrf-token" content="<?php echo csrfToken(); ?>">
    <meta name="application-name" data-prefix="<?php echo getRoutePrefix() ?>"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
     <!-- Bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

     <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery-1.12.4.min.js" integrity="sha384-nvAa0+6Qg9clwYCGGPpDQLVpLNn0fRaROjHqs13t4Ggj3Ez50XnGQqc/r8MhnRDZ" crossorigin="anonymous"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.11.2/jquery.mask.min.js" integrity="sha512-Y/GIYsd+LaQm6bGysIClyez2HGCIN1yrs94wUrHoRAD5RSURkqqVQEU6mM51O90hqS80ABFTGtiDpSXd2O05nw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    

    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    <script src="<?php echo resource('/js/app.js') ?>"></script>
    <link rel="stylesheet" type="text/css" href="<?php echo resource('/css/style.css') ?>">
    <script src="<?php echo resource('/js/translate.json') ?>"></script>
    <?php   if (!empty($this->getMeta())) {
      foreach ($this->getMeta() as $key => $meta) { ?>
        <meta  <?php echo $meta['type']; ?>="<?php echo $meta['name']; ?>" content="<?php  echo $meta['content']; ?>" >
      <?php }
    } ?>
    <?php   if (!empty($this->getStyle())) {
      foreach ($this->getStyle() as $key => $style) { ?>
        <link rel="stylesheet" type="text/css" href="<?php echo $style ?>">
      <?php }
    } ?>
    <?php   if (!empty($this->getScript())) {
      foreach ($this->getScript() as $key => $script) { ?>
        <script type="text/javascript" src="<?php echo $script ?>"></script>
      <?php }
    } ?>

  </head>

  <body>

    <?php $this->render('parts/header'); ?>

    <div class="main container" style="padding-top: 10px;">
      <?php app\components\widgets\Breadcrumbs::widget(array('name' => 'Главная', 'href' => url('/'))); ?>
      <?php echo $content; ?>
    </div>
    
    <?php $this->render('parts/footer'); ?>

  </body>

</html>
