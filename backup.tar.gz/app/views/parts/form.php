
<?php echo $var1; ?>
<form>
	<input type="text" name="name" placeholder="Имя">
	<button>Отправить</button>
</form>