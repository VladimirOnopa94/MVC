<?php 

return [
	/*
		Роли 
	*/
	'roles' => [
		'user' => 1,
		'manager' => 2,
		'admin' => 3
	],
];

