<?php 

return [
	'dsn' => 'mysql:host=localhost;dbname=frameworkvag;charset=utf8',
	'user' => 'u_frameworkv',
	'password' => 'nHCrsFBg'
]; 